
import './App.css';
import SideBar from './component/SideBar';
import Header from './component/Header';
import User from './component/User';
import { BrowserRouter, Routes,  Route } from 'react-router-dom';
import Dashboard from './component/Dashboard';
import CalenderList from './component/CalenderList';







function App() {

  // console.log(data);
  return (
 <div className='container-main'>
  
<BrowserRouter>
<Header />
<SideBar/>
  <Routes >


 
  <Route path="/user" element={ <User />} />
  <Route path="/dashboard" element={ <Dashboard />} />
  <Route path="/list" element={ <CalenderList />} />

 

  </Routes>

  </BrowserRouter>
 </div>
 

  );
}

export default App;
