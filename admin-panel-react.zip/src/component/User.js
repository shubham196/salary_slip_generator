import React, { useState } from 'react';
import { BrowserRouter, Routes,  Route } from 'react-router-dom';
import { data } from './data';



export default function User() {
    const [search, setSearch] = useState('');
   
  const [isPopupOpen, setPopupOpen] = useState(false);
  const [isEditPopupOpen, setEditPopupOpen] = useState(false);
  const [isDeleteConfirmationOpen, setDeleteConfirmationOpen] = useState(false);
  

  const togglePopup = () => {
    setPopupOpen(!isPopupOpen);
  };
  const toggleEditPopup = () => {
    setEditPopupOpen(!isEditPopupOpen);
  };

  
  const toggleDeleteConfirmation = () => {
    setDeleteConfirmationOpen(!isDeleteConfirmationOpen);
  };

  const handleDelete = () => {
    // Handle delete logic here
    toggleDeleteConfirmation(); // Close delete confirmation popup after deletion
  };
  return (
    <>
  
  {/* <Navbar title="TextUtils" aboutText ="About" />

  <div className="container my-3">
  <TextForm heading = "Enter the text to analyze below"/>
  </div> */}


<div className="container">
        <div className="sign-in-container">
            <button className="button button-sign-in  open-popup-btn" onClick={togglePopup}>ADD USER</button>
            {isPopupOpen && (
        <div className="popup-overlay">
          <div className="popup-content">
            <span className="close-popup" onClick={togglePopup}>
              &times;
            </span>
            <form>
            <div class="form">
      <div class="title">Welcome</div>
      <div class="subtitle">Add User Details!</div>
      <div class="input-container ic1">
        <input id="firstname" class="input" type="text" placeholder=" " />
        <div class="cut"></div>
        <label For="firstname" class="placeholder">User name</label>
      </div>
      <div class="input-container ic2">
        <input id="lastname" class="input" type="text" placeholder=" " />
        <div class="cut"></div>
        <label For="lastname" class="placeholder">Customer Id</label>
      </div>
      <div class="input-container ic2">
        <input id="email" class="input" type="text" placeholder=" " />
        <div class="cut cut-short"></div>
        <label For="email" class="placeholder" >Email</label>
      </div>
      <button type="text" class="submit">Add User</button>
    </div>
                </form>
          </div>
        </div>
      )}
        </div>
        <div className="search-container-user">
    <i className="fas fa-search search-icon-user"></i>
    <input type="text" onChange={(e) => setSearch(e.target.value)}   placeholder="Search By Name ..." className="search-input-user" />
  </div>
        <h1>USER DATA</h1>
       

        <table className="table-container">
            <thead>
                <tr>
                    <th>User Name</th>
                    <th>Customer ID</th>
                    <th>Email</th>
                    <th>Edit</th>
                    <th>Delete</th>
                    <th>Card Link</th>
                </tr>
            </thead>
            <tbody>

           {data.filter((item) => {
            return search.toLowerCase() === ''
            ? item:item.name.toLowerCase().includes(search);
           })
           
           
           
           .map((item) => (
            <tr key={item.id}>
                 
                 <td>{item.name}</td>
                 <td><input type="text" className=
                 "custom-id-input-text" name="customer_id_1" /></td>
                 <td>{item.email}</td>
                 <td><button className="button button-edit"  onClick={toggleEditPopup}>Edit</button>
                 {isEditPopupOpen && (
     <div className="edit-popup-overlay">
     <div className="edit2-popup-overlay">
       <div className="popup-content">
       <span className="close-popup" onClick={toggleEditPopup}>
           &times;
         </span>
         <form>
         <div class="form">
   <div class="title">Welcome</div>
   <div class="subtitle">Edit User Details !</div>
   <div class="input-container ic1">
     <input id="firstname" class="input" type="text" placeholder=" " />
     <div class="cut"></div>
     <label For="firstname" class="placeholder">User Name</label>
   </div>
   <div class="input-container ic2">
     <input id="lastname" class="input" type="text" placeholder=" " />
     <div class="cut"></div>
     <label For="lastname" class="placeholder">Customer Id</label>
   </div>
   <div class="input-container ic2">
     <input id="email" class="input" type="text" placeholder=" " />
     <div class="cut cut-short"></div>
     <label For="email" class="placeholder" >Email</label>
   </div>
   <button type="text" class="submit">Edit User</button>
 </div>
             </form>
       </div>
     </div>
     </div>
   )}
                 </td>
                 <td>
             <button className="button button-delete" onClick={toggleDeleteConfirmation}>
               Delete
             </button>
             {isDeleteConfirmationOpen && (
 <div className="delete-overlay">
 <div className="delete-confirmation">
   <p>Are you sure you want to delete?</p>
   <div className="button-container">
     <button className="button button-yes" onClick={handleDelete}>
       Yes
     </button>
     <button className="button button-no" onClick={toggleDeleteConfirmation}>
       No
     </button>
   </div>
 </div>
</div>

)}
           </td>
                 <td className="button-container">
                     <button className="button button-openLink">Open Link</button>
                     <button className="button button-copy">Copy</button>
                 </td>

                 
             </tr>
           ))}
                
                {/* <tr>
                    <td>Jane Smith</td>
                    <td><input type="text" name="customer_id_1" /></td>
                    <td>jane@example.com</td>
                    <td><button className="button button-edit">Edit</button></td>
                    <td><button className="button button-delete">Delete</button></td>
                    <td className="button-container">
                        <button className="button button-openLink">Open Link</button>
                        <button className="button button-copy">Copy</button>
                    </td>
                </tr>
                
                <tr>
                    <td>Bob Johnson</td>
                    <td><input type="text" name="customer_id_1" /></td>
                    <td>bob@example.com</td>
                    <td><button className="button button-edit">Edit</button></td>
                    <td><button className="button button-delete">Delete</button></td>
                    <td className="button-container">
                        <button className="button button-openLink">Open Link</button>
                        <button className="button button-copy">Copy</button>
                    </td>
                </tr>
                <tr>
                    <td>Alice Brown</td>
                    <td><input type="text" name="customer_id_1" /></td>
                    <td>alice@example.com</td>
                    <td><button className="button button-edit">Edit</button></td>
                    <td><button className="button button-delete">Delete</button></td>
                    <td className="button-container">
                        <button className="button button-openLink">Open Link</button>
                        <button className="button button-copy">Copy</button>
                    </td>
                </tr>
               
              
               */}
                
            </tbody>
        </table>

    </div>

 
    </>
  );
}

