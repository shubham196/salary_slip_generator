import React from 'react'

export default function Logo() {
  return (
    <div className="logo">
    {/* Your logo */}
    <img src='./assets/images/logo.png' alt='' />
    <h1>Logo</h1>
  </div>
  )
}
