export const data = [
    {
        id: "1",
       
        name: "John doe",
      
        email:"john.doe@gmail.com",
    },

    {
        id: "2",
        name: "Bob doe",
      
        email:"bob.doe@gmail.com",
    },


    {
        id: "3",
        name: "Lon doe",
      
        email:"lon.doe@gmail.com",
    },


    {
        id: "4",
        name: "Bornie doe",
      
        email:"bornie.doe@gmail.com",
    },

    {
        id: "5",
        name: "Lobby doe",
      
        email:"lobby.doe@gmail.com",
    },

]