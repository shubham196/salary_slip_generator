import React, { useState } from 'react';
import { BrowserRouter, Routes,  Route } from 'react-router-dom';

export default function Dashboard() {
  return (
<div className="container">
    <div className='dashboard-container'>
      <h1>HI , I AM A DASHBOARD </h1 >
      </div>
    </div>
  )
}
