/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

var axios = require('axios');

/**
 * Attaches a given access token to a MS Graph API call
 * @param endpoint: REST API endpoint to call
 * @param accessToken: raw access token string
 */
async function fetch(endpoint, accessToken) {
    const options = {
        headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Prefer': 'outlook.timezone="India Standard Time"'
        }
    };

    console.log(`request made to ${endpoint} at: & Access Token : ${accessToken}` + new Date().toString());

    try {
        const response = await axios.get(endpoint, options);
        // console.log("Hey i am Response",response.data);
        return await response.data;
    } catch (error) {
        console.log("Hey i am error",error);
        throw new Error(error);
    }
}

module.exports = fetch;
